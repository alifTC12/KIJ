#include <stdio.h>
#include <stdlib.h>

struct node
{
    int value;
    struct node *next;
};

struct node *head;
struct node *tail;

struct node* append(int nilai)
{
    struct node *ptr;
    struct node *t;
    ptr=head;
    while (ptr->next!=tail ) ptr=ptr->next;
    t=(struct node *)malloc(sizeof(*t));
    t->value=nilai;
    t->next=tail;
    ptr->next=t;
    return ptr;
}
void delete(struct node *ptr)
{
    struct node *t;
    t=ptr->next;
    ptr->next=ptr->next->next;
    free(t);

}
void init()
{
    head=(struct node *)malloc(sizeof(*head));
    tail=(struct node *)malloc (sizeof(*tail));
    head->next=tail;
    tail->next=tail;
}
int main()
{

char str[128];
char *ptr2;


struct node *ptr;

init();

ptr=append(10);
ptr=append(20);
ptr=append(30);
ptr=append(40);
ptr=append(50);

delete(ptr);
strcpy (str, "123456 789asdf");
strtok_r (str, " ", &ptr2);


ptr=head->next;
while (ptr != tail) {
	printf("%d\n",ptr->value);
	ptr = ptr->next;
	};
	printf ("'%s'  '%s'\n", str, ptr2);
}

